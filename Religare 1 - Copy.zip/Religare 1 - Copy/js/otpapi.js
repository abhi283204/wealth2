$(document).ready(function () {
  
});
function isCharsInBag(s, bag) {
    var i;
    for (i = 0; i < s.length; i++) {
        var c = s.charAt(i);
        if (bag.indexOf(c) == -1)
            return false;
    }
    return true;
}





function kp_numeric(e) {
    if (window.event) {
        // for IE, e.keyCode or window.event.keyCode can be used
        keynum = e.keyCode;
    }
    else if (e.which) {
        // netscape
        keynum = e.which;
    }
    else {
        // no event, so pass through
        return true;
    }
    if ((keynum != 46) && (keynum != 8) && (keynum < 48 || keynum > 57))
        return false;

}






function OnSuccess(response) {
    var msg = response.d;
    $("#ctl00_ContentPlaceHolder1_hdnOTPID").val(msg);
    $("#ctl00_ContentPlaceHolder1_hdnOTPID").html(msg);
}



function check_mobile() {
    var mobile = $("#txtMobile").val();
    String.prototype.startsWith = function (str) {
        return (this.indexOf(str) === 0);
    }
    if (mobile.startsWith("0")) // true
    {
        alert("please enter mobile number without zero prefix");
        $("#txtMobile").val('');
        return false;
    }
    if (!isCharsInBag(mobile, "0123456789")) {
        alert("Mobile must only contain Numbers");
        return false;
    }
    if (mobile.length == 10) {
                NewSendOTP();
    }

}

function NewSendOTP() 
{
  
    var mobile = $("#txtMobile").val();
    var campaigncode = $("#hdnCampaignCode").val();
    var firstname = $("#txtName").val();
    var emailid = $("#txtEmailID").val();
     var utmkeyword = $("#hdnutmkeyword").val();
    var utmadgroup = $("#hdnutmadgroup").val();
    var utmcampaign = $("#hdnutmcampaign").val();
    var utmsource = $("#hdnutmsource").val();



    if (mobile.length == 10) {
        $.ajax({
            type: "POST",
            url: "otpapi.aspx/SMSOTP",
            async: false,
           // data: "{mobileno:'" + mobile + "'}",
            data: "{mobileno:'" + mobile + "',camcode:'" + campaigncode + "',firstname:'" + firstname + "',emailid:'" + emailid + "',Utm_Source:'" + utmsource + "',Utm_Campaign:'" + utmcampaign + "',Utm_Addgroup:'" + utmadgroup + "',Utm_Keyword:'" + utmkeyword + "'  }",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: OnSuccessNew,
            
        });
    }  
}

function check_mobile1() {
    var mobile = $("#txtMobile").val();
    String.prototype.startsWith = function (str) {
        return (this.indexOf(str) === 0);
    }
    if (mobile.startsWith("0")) // true
    {
        alert("please enter mobile number without zero prefix");
        $("#txtMobile").val('');
        return false;
    }
    if (!isCharsInBag(mobile, "0123456789")) {
        alert("Mobile must only contain Numbers");
        return false;
    }
    if (mobile.length == 10) {
                NewSendOTP1();
    }

}

function NewSendOTP1() 
{
  
    var mobile = $("#txtMobile").val();
    var campaigncode = $("#hdnCampaignCode").val();
    var firstname = $("#txtName").val();
    var emailid = $("#txtEmailID").val();
     var utmkeyword = $("#hdnutmkeyword").val();
    var utmadgroup = $("#hdnutmadgroup").val();
    var utmcampaign = $("#hdnutmcampaign").val();
    var utmsource = $("#hdnutmsource").val();



    if (mobile.length == 10) {
        $.ajax({
            type: "POST",
            url: "../otpapi.aspx/SMSOTP",
            async: false,
           // data: "{mobileno:'" + mobile + "'}",
            data: "{mobileno:'" + mobile + "',camcode:'" + campaigncode + "',firstname:'" + firstname + "',emailid:'" + emailid + "',Utm_Source:'" + utmsource + "',Utm_Campaign:'" + utmcampaign + "',Utm_Addgroup:'" + utmadgroup + "',Utm_Keyword:'" + utmkeyword + "'  }",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: OnSuccessNew,
            
        });
    }  
}

function check_mobile2() {
    var mobile = $("#txtMobile").val();
    String.prototype.startsWith = function (str) {
        return (this.indexOf(str) === 0);
    }
    if (mobile.startsWith("0")) // true
    {
        alert("please enter mobile number without zero prefix");
        $("#txtMobile").val('');
        return false;
    }
    if (!isCharsInBag(mobile, "0123456789")) {
        alert("Mobile must only contain Numbers");
        return false;
    }
    if (mobile.length == 10) {
                NewSendOTP2();
    }

}

function NewSendOTP2() 
{
  
    var mobile = $("#txtMobile").val();
    var campaigncode = $("#hdnCampaignCode").val();
    var firstname = $("#txtName").val();
    var emailid = $("#txtEmailID").val();
     var utmkeyword = $("#hdnutmkeyword").val();
    var utmadgroup = $("#hdnutmadgroup").val();
    var utmcampaign = $("#hdnutmcampaign").val();
    var utmsource = $("#hdnutmsource").val();



    if (mobile.length == 10) {
        $.ajax({
            type: "POST",
            url: "religare-open-an-account.aspx/SMSOTP",
            async: false,
           // data: "{mobileno:'" + mobile + "'}",
            data: "{mobileno:'" + mobile + "',camcode:'" + campaigncode + "',firstname:'" + firstname + "',emailid:'" + emailid + "',Utm_Source:'" + utmsource + "',Utm_Campaign:'" + utmcampaign + "',Utm_Addgroup:'" + utmadgroup + "',Utm_Keyword:'" + utmkeyword + "'  }",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: OnSuccessNew,
            
        });
    }  
}

function check_mobile3() {
    var mobile = $("#txtMobile").val();
    String.prototype.startsWith = function (str) {
        return (this.indexOf(str) === 0);
    }
    if (mobile.startsWith("0")) // true
    {
        alert("please enter mobile number without zero prefix");
        $("#txtMobile").val('');
        return false;
    }
    if (!isCharsInBag(mobile, "0123456789")) {
        alert("Mobile must only contain Numbers");
        return false;
    }
    if (mobile.length == 10) {
                NewSendOTP3();
    }

}

function NewSendOTP3() 
{
  
    var mobile = $("#txtMobile").val();
    var campaigncode = $("#hdnCampaignCode").val();
    var firstname = $("#txtName").val();
    var emailid = $("#txtEmailID").val();
     var utmkeyword = $("#hdnutmkeyword").val();
    var utmadgroup = $("#hdnutmadgroup").val();
    var utmcampaign = $("#hdnutmcampaign").val();
    var utmsource = $("#hdnutmsource").val();



    if (mobile.length == 10) {
        $.ajax({
            type: "POST",
            url: "../../otpapi.aspx/SMSOTP",
            async: false,
           // data: "{mobileno:'" + mobile + "'}",
            data: "{mobileno:'" + mobile + "',camcode:'" + campaigncode + "',firstname:'" + firstname + "',emailid:'" + emailid + "',Utm_Source:'" + utmsource + "',Utm_Campaign:'" + utmcampaign + "',Utm_Addgroup:'" + utmadgroup + "',Utm_Keyword:'" + utmkeyword + "'  }",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: OnSuccessNew,
            
        });
    }  
}

function check_mobile4() {
    var mobile = $("#txtMobile").val();
    String.prototype.startsWith = function (str) {
        return (this.indexOf(str) === 0);
    }
    if (mobile.startsWith("0")) // true
    {
        alert("please enter mobile number without zero prefix");
        $("#txtMobile").val('');
        return false;
    }
    if (!isCharsInBag(mobile, "0123456789")) {
        alert("Mobile must only contain Numbers");
        return false;
    }
    if (mobile.length == 10) {
                NewSendOTP4();
    }

}

function NewSendOTP4() 
{
  
    var mobile = $("#txtMobile").val();
    var campaigncode = $("#hdnCampaignCode").val();
    var firstname = $("#txtName").val();
    var emailid = $("#txtEmailID").val();
     var utmkeyword = $("#hdnutmkeyword").val();
    var utmadgroup = $("#hdnutmadgroup").val();
    var utmcampaign = $("#hdnutmcampaign").val();
    var utmsource = $("#hdnutmsource").val();



    if (mobile.length == 10) {
        $.ajax({
            type: "POST",
            url: "../otpapi.aspx/NewSMSOTP",
            async: false,
           // data: "{mobileno:'" + mobile + "'}",
            data: "{mobileno:'" + mobile + "',camcode:'" + campaigncode + "',firstname:'" + firstname + "',emailid:'" + emailid + "',Utm_Source:'" + utmsource + "',Utm_Campaign:'" + utmcampaign + "',Utm_Addgroup:'" + utmadgroup + "',Utm_Keyword:'" + utmkeyword + "'  }",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: OnSuccessNew,
            
        });
    }  
}

function OnSuccessNew(response) {
    var msg = response.d;
    $("#ctl00_ContentPlaceHolder1_hdnOTPID").val(msg);
    $("#ctl00_ContentPlaceHolder1_hdnOTPID").html(msg);
  
   
}

function check_mobile5() {
    var mobile = $("#txtMobile").val();
    String.prototype.startsWith = function (str) {
        return (this.indexOf(str) === 0);
    }
    if (mobile.startsWith("0")) // true
    {
        alert("please enter mobile number without zero prefix");
        $("#txtMobile").val('');
        return false;
    }
    if (!isCharsInBag(mobile, "0123456789")) {
        alert("Mobile must only contain Numbers");
        return false;
    }
    if (mobile.length == 10) {
                NewSendOTP5();
    }

}

function NewSendOTP5() 
{
  
    var mobile = $("#txtMobile").val();
    var campaigncode = $("#hdnCampaignCode").val();
    var firstname = $("#txtName").val();
    var emailid = $("#txtEmailID").val();
     var utmkeyword = $("#hdnutmkeyword").val();
    var utmadgroup = $("#hdnutmadgroup").val();
    var utmcampaign = $("#hdnutmcampaign").val();
    var utmsource = $("#hdnutmsource").val();



    if (mobile.length == 10) {
        $.ajax({
            type: "POST",
            url: "../otpapi.aspx/DONOTSMSOTP",
            async: false,
           // data: "{mobileno:'" + mobile + "'}",
            data: "{mobileno:'" + mobile + "',camcode:'" + campaigncode + "',firstname:'" + firstname + "',emailid:'" + emailid + "',Utm_Source:'" + utmsource + "',Utm_Campaign:'" + utmcampaign + "',Utm_Addgroup:'" + utmadgroup + "',Utm_Keyword:'" + utmkeyword + "'  }",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: OnSuccessNew,
            
        });
    }  
}
function GenerateOTP() {
debugger;
    var mobile = $("#txtMobile").val();
    String.prototype.startsWith = function (str) {
        return (this.indexOf(str) === 0);
    }
    if (mobile.startsWith("0")) // true
    {
        alert("please enter mobile number without zero prefix");
        $("#txtMobile").val('');
        return false;
    }
    if (!isCharsInBag(mobile, "0123456789")) {
        alert("Mobile must only contain Numbers");
        return false;
    }
    if (mobile.length == 10) {
                NewSendOTP6();
    }

}
function NewSendOTP6() 
{
debugger;
  
    var mobile = $("#txtMobile").val();
    //var campaigncode = $("#hdnCampaignCode").val();
    var campaigncode = 'EDAAO';
    var firstname = $("#txtName").val();
    var emailid = $("#txtEmailID").val();
     var utmkeyword = $("#hdnutmkeyword").val();
    var utmadgroup = $("#hdnutmadgroup").val();
    var utmcampaign = $("#hdnutmcampaign").val();
    var utmsource = $("#hdnutmsource").val();



    if (mobile.length == 10) {
    debugger;
        $.ajax({
            type: "POST",
            url: "https://secure.religareonline.com/CampaignPages/otpapi.aspx/NewSMSOTP",
            async: false,
           // data: "{mobileno:'" + mobile + "'}",
            data: "{mobileno:'" + mobile + "',camcode:'" + campaigncode + "',firstname:'" + firstname + "',emailid:'" + emailid + "',Utm_Source:'" + utmsource + "',Utm_Campaign:'" + utmcampaign + "',Utm_Addgroup:'" + utmadgroup + "',Utm_Keyword:'" + utmkeyword + "'  }",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: OnSuccessNew,
            
        });
    }  
}

